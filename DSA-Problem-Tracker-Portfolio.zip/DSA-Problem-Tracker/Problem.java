import java.time.LocalDate;

/**
 * Represents one DSA practice problem.
 */
public class Problem {
    private final int id;
    private String title;
    private String topic;
    private String difficulty;
    private String platform;
    private boolean solved;
    private final LocalDate dateAdded;

    public Problem(int id, String title, String topic, String difficulty,
                   String platform, boolean solved) {
        this(id, title, topic, difficulty, platform, solved, LocalDate.now());
    }

    public Problem(int id, String title, String topic, String difficulty,
                   String platform, boolean solved, LocalDate dateAdded) {
        if (id <= 0) {
            throw new IllegalArgumentException("Problem ID must be positive.");
        }
        this.id = id;
        setTitle(title);
        setTopic(topic);
        setDifficulty(difficulty);
        setPlatform(platform);
        this.solved = solved;
        this.dateAdded = dateAdded == null ? LocalDate.now() : dateAdded;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getTopic() { return topic; }
    public String getDifficulty() { return difficulty; }
    public String getPlatform() { return platform; }
    public boolean isSolved() { return solved; }
    public LocalDate getDateAdded() { return dateAdded; }

    public void setTitle(String title) { this.title = requireText(title, "Title"); }
    public void setTopic(String topic) { this.topic = requireText(topic, "Topic"); }

    public void setDifficulty(String difficulty) {
        String value = requireText(difficulty, "Difficulty");
        if (!value.equalsIgnoreCase("Easy")
                && !value.equalsIgnoreCase("Medium")
                && !value.equalsIgnoreCase("Hard")) {
            throw new IllegalArgumentException("Difficulty must be Easy, Medium, or Hard.");
        }
        this.difficulty = value.substring(0, 1).toUpperCase()
                + value.substring(1).toLowerCase();
    }

    public void setPlatform(String platform) {
        this.platform = requireText(platform, "Platform");
    }

    public void setSolved(boolean solved) { this.solved = solved; }

    private static String requireText(String value, String field) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(field + " cannot be empty.");
        }
        return value.trim();
    }

    // Pipe-delimited storage format, with pipes in fields disallowed.
    public String toFileLine() {
        return id + "|" + clean(title) + "|" + clean(topic) + "|"
                + difficulty + "|" + clean(platform) + "|" + solved + "|" + dateAdded;
    }

    public static Problem fromFileLine(String line) {
        String[] parts = line.split("\\|", -1);
        if (parts.length != 7) {
            throw new IllegalArgumentException("Invalid problem record.");
        }
        return new Problem(
                Integer.parseInt(parts[0]), parts[1], parts[2], parts[3],
                parts[4], Boolean.parseBoolean(parts[5]), LocalDate.parse(parts[6]));
    }

    private static String clean(String value) {
        return value.replace("|", "/").replace("\n", " ").replace("\r", " ");
    }

    @Override
    public String toString() {
        return String.format("%-4d | %-25s | %-16s | %-7s | %-14s | %-7s | %s",
                id, title, topic, difficulty, platform,
                solved ? "Solved" : "Pending", dateAdded);
    }
}
