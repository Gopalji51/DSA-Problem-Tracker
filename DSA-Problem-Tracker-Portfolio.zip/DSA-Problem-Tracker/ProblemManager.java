import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Handles problem CRUD, searching, sorting, statistics, and file persistence.
 */
public class ProblemManager {
    private final List<Problem> problems = new ArrayList<>();
    private final Path storagePath;

    public ProblemManager() {
        this(Paths.get("problems.txt"));
    }

    public ProblemManager(Path storagePath) {
        this.storagePath = storagePath;
        loadFromFile();
    }

    public List<Problem> getAllProblems() {
        return new ArrayList<>(problems);
    }

    public boolean addProblem(Problem problem) {
        if (findById(problem.getId()).isPresent()) {
            return false;
        }
        problems.add(problem);
        saveToFile();
        return true;
    }

    public Optional<Problem> findById(int id) {
        return problems.stream().filter(p -> p.getId() == id).findFirst();
    }

    public List<Problem> searchByTitle(String query) {
        String term = query == null ? "" : query.trim().toLowerCase();
        List<Problem> matches = new ArrayList<>();
        for (Problem problem : problems) {
            if (problem.getTitle().toLowerCase().contains(term)) {
                matches.add(problem);
            }
        }
        return matches;
    }

    public boolean updateProblem(int id, String title, String topic,
                                 String difficulty, String platform) {
        Optional<Problem> match = findById(id);
        if (!match.isPresent()) {
            return false;
        }
        Problem p = match.get();
        p.setTitle(title);
        p.setTopic(topic);
        p.setDifficulty(difficulty);
        p.setPlatform(platform);
        saveToFile();
        return true;
    }

    public boolean deleteProblem(int id) {
        boolean removed = problems.removeIf(p -> p.getId() == id);
        if (removed) {
            saveToFile();
        }
        return removed;
    }

    public boolean markSolved(int id) {
        Optional<Problem> match = findById(id);
        if (!match.isPresent()) {
            return false;
        }
        match.get().setSolved(true);
        saveToFile();
        return true;
    }

    public List<Problem> sortByDifficulty() {
        List<Problem> sorted = getAllProblems();
        Map<String, Integer> rank = new HashMap<>();
        rank.put("Easy", 1);
        rank.put("Medium", 2);
        rank.put("Hard", 3);
        sorted.sort(Comparator.comparingInt(p -> rank.getOrDefault(p.getDifficulty(), 4)));
        return sorted;
    }

    public List<Problem> sortByTopic() {
        List<Problem> sorted = getAllProblems();
        sorted.sort(Comparator.comparing(Problem::getTopic, String.CASE_INSENSITIVE_ORDER));
        return sorted;
    }

    public int getSolvedCount() {
        int count = 0;
        for (Problem p : problems) {
            if (p.isSolved()) count++;
        }
        return count;
    }

    public int getPendingCount() {
        return problems.size() - getSolvedCount();
    }

    public Map<String, Integer> getTopicCounts() {
        Map<String, Integer> counts = new HashMap<>();
        for (Problem p : problems) {
            counts.put(p.getTopic(), counts.getOrDefault(p.getTopic(), 0) + 1);
        }
        return counts;
    }

    private void loadFromFile() {
        if (!Files.exists(storagePath)) {
            return;
        }
        try {
            for (String line : Files.readAllLines(storagePath, StandardCharsets.UTF_8)) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;
                try {
                    Problem problem = Problem.fromFileLine(line);
                    if (!findById(problem.getId()).isPresent()) problems.add(problem);
                } catch (RuntimeException invalidLine) {
                    System.err.println("Skipping invalid record in " + storagePath + ": " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Could not load problems: " + e.getMessage());
        }
    }

    private void saveToFile() {
        List<String> lines = new ArrayList<>();
        lines.add("# id|title|topic|difficulty|platform|solved|dateAdded");
        for (Problem p : problems) lines.add(p.toFileLine());
        try {
            Path parent = storagePath.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.write(storagePath, lines, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
        } catch (IOException e) {
            System.err.println("Could not save problems: " + e.getMessage());
        }
    }
}
