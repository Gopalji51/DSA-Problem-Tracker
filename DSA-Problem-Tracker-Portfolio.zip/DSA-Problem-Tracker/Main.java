import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;

/**
 * Console entry point for the DSA Problem Tracker.
 */
public class Main {
    private static final Scanner SCANNER = new Scanner(System.in);

    public static void main(String[] args) {
        ProblemManager manager = new ProblemManager();
        System.out.println("\n==================================");
        System.out.println("       DSA PROBLEM TRACKER");
        System.out.println("==================================");

        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Choose an option: ");
            try {
                switch (choice) {
                    case 1: addProblem(manager); break;
                    case 2: printProblems(manager.getAllProblems()); break;
                    case 3: searchProblem(manager); break;
                    case 4: updateProblem(manager); break;
                    case 5: deleteProblem(manager); break;
                    case 6: markSolved(manager); break;
                    case 7: printProblems(manager.sortByDifficulty()); break;
                    case 8: printProblems(manager.sortByTopic()); break;
                    case 9: showStatistics(manager); break;
                    case 10:
                        running = false;
                        System.out.println("Progress saved. Keep coding. Goodbye!");
                        break;
                    default:
                        System.out.println("Please choose a number from 1 to 10.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Input error: " + e.getMessage());
            }
        }
        SCANNER.close();
    }

    private static void printMenu() {
        System.out.println("\n1. Add Problem");
        System.out.println("2. View All Problems");
        System.out.println("3. Search Problem");
        System.out.println("4. Update Problem");
        System.out.println("5. Delete Problem");
        System.out.println("6. Mark as Solved");
        System.out.println("7. Sort by Difficulty");
        System.out.println("8. Sort by Topic");
        System.out.println("9. Show Statistics");
        System.out.println("10. Exit");
    }

    private static void addProblem(ProblemManager manager) {
        int id = readInt("ID: ");
        String title = readText("Title: ");
        String topic = readText("Topic: ");
        String difficulty = readText("Difficulty (Easy/Medium/Hard): ");
        String platform = readText("Platform: ");
        boolean added = manager.addProblem(new Problem(id, title, topic, difficulty, platform, false));
        System.out.println(added ? "Problem added and saved." : "That ID already exists.");
    }

    private static void searchProblem(ProblemManager manager) {
        int id = readInt("Search by ID (0 to search title): ");
        if (id > 0) {
            Optional<Problem> found = manager.findById(id);
            System.out.println(found.map(Object::toString).orElse("Problem not found."));
        } else {
            String title = readText("Enter title or part of title: ");
            printProblems(manager.searchByTitle(title));
        }
    }

    private static void updateProblem(ProblemManager manager) {
        int id = readInt("ID to update: ");
        String title = readText("New title: ");
        String topic = readText("New topic: ");
        String difficulty = readText("New difficulty (Easy/Medium/Hard): ");
        String platform = readText("New platform: ");
        System.out.println(manager.updateProblem(id, title, topic, difficulty, platform)
                ? "Problem updated and saved." : "Problem not found.");
    }

    private static void deleteProblem(ProblemManager manager) {
        int id = readInt("ID to delete: ");
        System.out.println(manager.deleteProblem(id)
                ? "Problem deleted." : "Problem not found.");
    }

    private static void markSolved(ProblemManager manager) {
        int id = readInt("ID to mark solved: ");
        System.out.println(manager.markSolved(id)
                ? "Marked as solved and saved." : "Problem not found.");
    }

    private static void showStatistics(ProblemManager manager) {
        System.out.println("\n--- Your Statistics ---");
        System.out.println("Total problems : " + manager.getAllProblems().size());
        System.out.println("Solved         : " + manager.getSolvedCount());
        System.out.println("Pending        : " + manager.getPendingCount());
        System.out.println("Topics         : " + manager.getTopicCounts());
    }

    private static void printProblems(List<Problem> list) {
        if (list.isEmpty()) {
            System.out.println("No problems found.");
            return;
        }
        System.out.printf("%-4s | %-25s | %-16s | %-7s | %-14s | %-7s | %s%n",
                "ID", "Title", "Topic", "Level", "Platform", "Status", "Date Added");
        System.out.println("-".repeat(105));
        for (Problem p : list) System.out.println(p);
    }

    private static int readInt(String prompt) {
        System.out.print(prompt);
        String value = SCANNER.nextLine().trim();
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Please enter a whole number.");
        }
    }

    private static String readText(String prompt) {
        System.out.print(prompt);
        String value = SCANNER.nextLine().trim();
        if (value.isEmpty()) throw new IllegalArgumentException("This field cannot be empty.");
        return value;
    }
}
