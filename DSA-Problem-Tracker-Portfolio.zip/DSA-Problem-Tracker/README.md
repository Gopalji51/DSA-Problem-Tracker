# DSA Problem Tracker

A Java console application for organizing DSA practice problems. It demonstrates object-oriented programming, collections, searching, sorting, CRUD operations, exception handling, and text-file persistence.

## Features

- Add, list, search, update, and delete problems
- Mark problems as solved
- Search by ID or title
- Sort by difficulty or topic
- View solved/pending counts and topic statistics
- Persist records to `problems.txt` between runs
- Input validation and helpful error messages

## Project structure

```text
DSA-Problem-Tracker/
├── Main.java
├── Problem.java
├── ProblemManager.java
├── problems.txt
├── index.html
├── style.css
├── script.js
└── README.md
```

The Java files are the console application. The HTML/CSS/JavaScript files make a portfolio website with a browser-based interactive demo. The browser demo is separate from the Java application and uses localStorage.

## Requirements

- Java 11 or later
- Any terminal or Java IDE

## Run the Java application

Place the three `.java` files and `problems.txt` in the same folder, then run:

```bash
javac Main.java Problem.java ProblemManager.java
java Main
```

The app reads existing records from `problems.txt` at startup and writes changes after add, update, delete, or mark-solved operations.

## Run the portfolio website

Open `index.html` in your browser. No package installation is required. The demo stores its own browser data in localStorage and does not connect to the Java console program.

## Concepts demonstrated

| Concept | Example |
|---|---|
| Encapsulation | Private fields in `Problem` |
| Collections | `ArrayList`, `List`, `HashMap` |
| Searching | ID lookup and title search |
| Sorting | Difficulty and topic sorting |
| CRUD | Create, read, update, delete |
| File handling | Reading/writing `problems.txt` |
| Exception handling | Input validation and invalid records |
| Statistics | Solved, pending, topic counts |

## GitHub setup

1. Create a new GitHub repository named `dsa-problem-tracker`.
2. Upload the files from this folder or push the folder using Git.
3. To publish the portfolio website, open repository **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. After GitHub Pages finishes deploying, use its URL in your portfolio.

## Future improvements

- Add JUnit tests
- Export statistics to CSV
- Add tags, notes, and solution URLs
- Connect the web interface to a Java REST API and database

## License

MIT — see `LICENSE`.
